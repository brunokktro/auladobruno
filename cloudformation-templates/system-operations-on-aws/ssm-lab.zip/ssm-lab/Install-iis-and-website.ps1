﻿# This PowerShell script installs the IIS webserver and then installs a new index page
Import-Module ServerManager 
Add-WindowsFeature Web-Server -IncludeAllSubFeature
Invoke-WebRequest https://s3.amazonaws.com/ssmdocs/ssmlab/package2.pak -OutFile c:\inetpub\wwwroot\index.html
