﻿net.exe user administrator {{ssm:AdminPass}}
echo "You just had SSM change the Admin password to: "
echo {{ssm:AdminPass}}