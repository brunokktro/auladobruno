﻿#!/bin/bash
# This shell script checks to see if the sshd service is running - starts if if it isn't

service=sshd 
if (( $(ps -ef | grep -v grep | grep $service | wc -l) > 0 ))
then
echo "$service is running"
else
sudo /etc/init.d/sshd start
echo "SSH damen started by SSM"
fi
