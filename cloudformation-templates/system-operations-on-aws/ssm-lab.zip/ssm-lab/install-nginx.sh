#!/bin/bash
#sudo command is is not needed in EC2 Systems Manager Run Command

# If you want to see the entire output you must add loging to an s3 bucket. Or do it is steps - each piece seperate
#yum update -y

# Install NGINX
yum install nginx -y 
echo "Installed NGINX"

## Start NGINX
service nginx start
echo "Started NGINX"

## Add NGINX service start to boot sequence
chkconfig nginx on
echo "Set NGINX to restart on boot"

# Add <file>.html to /usr/share/nginx/html
wget -O /usr/share/nginx/html/index.html https://s3.amazonaws.com/ssmdocs/ssmlab/package2.pak
echo "Installed the website"
