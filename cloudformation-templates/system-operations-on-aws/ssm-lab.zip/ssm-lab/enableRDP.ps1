﻿# This PowerShell script will allow port 3389 through the Windows Firewall
# If RDP is not enabled it will enable it.

Enable-NetFirewallRule -DisplayGroup "Remote Desktop"

$RDPenabled = Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections

if ($RDPenabled.fDenyTSConnections -eq 1) {
Write-Host "RDP was disabled - SSM will now enable"
Set-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server' -Name fDenyTSConnections -Value 0
net stop UmRdpService /y
net stop TermService /y
net start TermService
net start UmRdpService
}
else { Write-Host "RDP was already enabled" }
